﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BikeParts
{
    public partial class AdminAddParts : Form
    {
        public AdminAddParts()
        {
            InitializeComponent();
        }

        private void AdminAddParts_Load(object sender, EventArgs e)
        {
            LoadPartsToGrid(); 
        }

       
        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }
        private void AdminAddParts_Load_1(object sender, EventArgs e)
        {
            LoadPartsToGrid();
        }

        private void addUsers_addbtn_Click(object sender, EventArgs e)
        {
            string partName = Addpartstxt.Text.Trim();
            string priceText = Price.Text.Trim(); // Assuming textBox1 is for the price

            if (string.IsNullOrEmpty(partName))
            {
                MessageBox.Show("Please enter a part name.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(priceText, out decimal price))
            {
                MessageBox.Show("Please enter a valid price.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Call the method to add the part and price to the database
            AddPartToDatabase(partName, price);

            // Optionally, clear the text boxes after adding
            Addpartstxt.Clear();
            Price.Clear();
        }

        private void Addpartstxt_TextChanged(object sender, EventArgs e)
        {
            // Placeholder for Addpartstxt text change event
        }

        private void AddPartToDatabase(string partName, decimal price)
        {
            string query = "INSERT INTO AdminData (PartName, Price) VALUES (@partName, @price)";

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@partName", partName);
                        cmd.Parameters.AddWithValue("@price", price);
                        cmd.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Part added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                LoadPartsToGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding part: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadPartsToGrid()
        {
            string query = "SELECT PartName, Price FROM AdminData"; // Now includes the Price column

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open();

                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading parts: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                string partName = dataGridView1.Rows[e.RowIndex].Cells["PartName"].Value.ToString();
                string price = dataGridView1.Rows[e.RowIndex].Cells["Price"].Value.ToString();
                MessageBox.Show($"You clicked on part: {partName}, Price: {price}", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
      
        private void Backbuttton_Click(object sender, EventArgs e)
        {
            Admin form = new Admin();
            form.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void addUsers_removebtn_Click(object sender, EventArgs e)
        {
            string partName = Addpartstxt.Text.Trim(); 
            string priceText =  Price.Text.Trim();  

            if (string.IsNullOrEmpty(partName))
            {
                MessageBox.Show("Please enter a part name.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string query;
            bool priceProvided = !string.IsNullOrEmpty(priceText);

            if (priceProvided)
            {
                if (!decimal.TryParse(priceText, out decimal price))
                {
                    MessageBox.Show("Please enter a valid price.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                query = "DELETE FROM AdminData WHERE PartName = @partName AND (Price = @price OR Price IS NULL)";
            }
            else
            {
                query = "DELETE FROM AdminData WHERE PartName = @partName";
            }

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open(); // Open the database connection
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        // Bind parameters to the query
                        cmd.Parameters.AddWithValue("@partName", partName);

                        if (priceProvided)
                        {
                            cmd.Parameters.AddWithValue("@price", Convert.ToDecimal(priceText));
                        }

                        int rowsAffected = cmd.ExecuteNonQuery(); // Execute the delete command

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Part removed successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Refresh the DataGridView to reflect the deletion
                            LoadPartsToGrid();
                        }
                        else
                        {
                            MessageBox.Show("No matching part found to remove.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error removing part: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            Addpartstxt.Clear();
            Price.Clear();
        }

        private void addUsers_clearbtn_Click(object sender, EventArgs e)
        {
            Addpartstxt.Text = string.Empty; 
            Price.Text = string.Empty;
        }

        private void addUsers_updatebtn_Click(object sender, EventArgs e)
        {
            string partName = Addpartstxt.Text.Trim(); 
            string priceText = Price.Text.Trim(); 

            if (string.IsNullOrEmpty(partName))
            {
                MessageBox.Show("Please enter a part name.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(priceText) || !decimal.TryParse(priceText, out decimal price))
            {
                MessageBox.Show("Please enter a valid price.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            UpdatePartInDatabase(partName, price);

            Addpartstxt.Clear();
            Price.Clear();
        }

        private void UpdatePartInDatabase(string partName, decimal price)
        {
            string query = "UPDATE AdminData SET Price = @price WHERE PartName = @partName";

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@partName", partName);
                        cmd.Parameters.AddWithValue("@price", price);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Part updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            LoadPartsToGrid();
                        }
                        else
                        {
                            MessageBox.Show("Part not found. Please check the part name.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating part: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
