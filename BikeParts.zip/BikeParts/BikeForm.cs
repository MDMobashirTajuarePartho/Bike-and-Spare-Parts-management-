﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BikeParts
{
    public partial class BikeForm : Form
    {
        public BikeForm()
        {
            InitializeComponent();
        }

        private void Homebtn_Click(object sender, EventArgs e)
        {
            Form1 home = new Form1();
            home.Show();
            this.Close();
        }

     
        private void LoadBikeDataToGrid()
        {
            using (SqlConnection con = DbConnection.GetConnection())
            {
                try
                {
                    con.Open();
                    string query = "SELECT BikeName, BikePrice FROM AdminData WHERE BikeName IS NOT NULL AND BikePrice IS NOT NULL";

                    using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count == 0)
                        {
                            MessageBox.Show("No bike data available in the database.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        dataGridView1.DataSource = dt; 
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)             {
                string bikeName = dataGridView1.Rows[e.RowIndex].Cells["BikeName"].Value.ToString();
                string bikePrice = dataGridView1.Rows[e.RowIndex].Cells["BikePrice"].Value.ToString();
                MessageBox.Show($"You clicked on bike: {bikeName}, Price: {bikePrice}", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void BikeForm_Load_1(object sender, EventArgs e)
        {
            LoadBikeDataToGrid();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
