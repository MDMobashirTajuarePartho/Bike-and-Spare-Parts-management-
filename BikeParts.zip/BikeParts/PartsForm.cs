﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BikeParts
{
    public partial class PartsForm : Form
    {
        public PartsForm()
        {
            InitializeComponent();
        }

        private void Homebtn_Click(object sender, EventArgs e)
        {
            Form1 homeForm = new Form1();
            homeForm.Show();
            this.Close();
        }

        private void PartsForm_Load(object sender, EventArgs e)
        {
            LoadPartsDataToGrid();
        }

        private void LoadPartsDataToGrid()
        {
            using (SqlConnection con = DbConnection.GetConnection())
            {
                try
                {
                    con.Open();
                    string query = "SELECT PartName, Price FROM AdminData WHERE PartName IS NOT NULL AND Price IS NOT NULL";

                    using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count == 0)
                        {
                            MessageBox.Show("No parts data available in the database.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }

                        dataGridView1.DataSource = dt; 
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                string partName = dataGridView1.Rows[e.RowIndex].Cells["PartName"].Value.ToString();
                string price = dataGridView1.Rows[e.RowIndex].Cells["Price"].Value.ToString();
                MessageBox.Show($"You clicked on part: {partName}, Price: {price}", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
