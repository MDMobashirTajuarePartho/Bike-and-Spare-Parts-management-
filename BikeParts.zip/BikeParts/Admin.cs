﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BikeParts
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

      

        private void button4_Click(object sender, EventArgs e)
        {
            AdminAddBikes adminAddBikes = new AdminAddBikes();
            adminAddBikes.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminAddParts adminAddParts = new AdminAddParts();
            adminAddParts.Show();
            this.Hide();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AdminAddUser adminAddUser = new AdminAddUser(); 
            adminAddUser.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AdminCustomers adminCustomers = new AdminCustomers();
            adminCustomers.Show();
            this.Hide();
        }

        
        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            
        }

       
        private void label4_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) 
            {
                
                string userName = dataGridView1.Rows[e.RowIndex].Cells["UserName"].Value.ToString();
                MessageBox.Show($"You clicked on user: {userName}", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        
        private void LoadUserInfoToGrid()
        {
            string query = "SELECT DateofBirth, Password, UserName, Name FROM Users";

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open(); 
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(query, connection);
                    DataTable dataTable = new DataTable(); 
                    dataAdapter.Fill(dataTable); 

                    dataGridView1.DataSource = dataTable;

                  
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading user info: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            LoadUserInfoToGrid();
        }
    }
}
