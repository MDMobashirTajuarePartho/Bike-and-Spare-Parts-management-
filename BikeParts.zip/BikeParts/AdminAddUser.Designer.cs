﻿namespace BikeParts
{
    partial class AdminAddUser
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.addUsers_clearbtn = new System.Windows.Forms.Button();
            this.addUsers_removebtn = new System.Windows.Forms.Button();
            this.addUsers_updatebtn = new System.Windows.Forms.Button();
            this.addUsers_addbtn = new System.Windows.Forms.Button();
            this.addUsers_password = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.addUsers_Username = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label5 = new System.Windows.Forms.Label();
            this.Backbuttton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.Backbuttton);
            this.panel1.Controls.Add(this.addUsers_clearbtn);
            this.panel1.Controls.Add(this.addUsers_removebtn);
            this.panel1.Controls.Add(this.addUsers_updatebtn);
            this.panel1.Controls.Add(this.addUsers_addbtn);
            this.panel1.Controls.Add(this.addUsers_password);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.addUsers_Username);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(4, 15);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(339, 682);
            this.panel1.TabIndex = 4;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // addUsers_clearbtn
            // 
            this.addUsers_clearbtn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.addUsers_clearbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.IndianRed;
            this.addUsers_clearbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.IndianRed;
            this.addUsers_clearbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_clearbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_clearbtn.Location = new System.Drawing.Point(161, 428);
            this.addUsers_clearbtn.Margin = new System.Windows.Forms.Padding(4);
            this.addUsers_clearbtn.Name = "addUsers_clearbtn";
            this.addUsers_clearbtn.Size = new System.Drawing.Size(135, 62);
            this.addUsers_clearbtn.TabIndex = 11;
            this.addUsers_clearbtn.Text = "Clear";
            this.addUsers_clearbtn.UseVisualStyleBackColor = false;
            this.addUsers_clearbtn.Click += new System.EventHandler(this.addUsers_clearbtn_Click);
            // 
            // addUsers_removebtn
            // 
            this.addUsers_removebtn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.addUsers_removebtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.IndianRed;
            this.addUsers_removebtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.IndianRed;
            this.addUsers_removebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_removebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_removebtn.Location = new System.Drawing.Point(4, 428);
            this.addUsers_removebtn.Margin = new System.Windows.Forms.Padding(4);
            this.addUsers_removebtn.Name = "addUsers_removebtn";
            this.addUsers_removebtn.Size = new System.Drawing.Size(135, 62);
            this.addUsers_removebtn.TabIndex = 10;
            this.addUsers_removebtn.Text = "Remove";
            this.addUsers_removebtn.UseVisualStyleBackColor = false;
            this.addUsers_removebtn.Click += new System.EventHandler(this.addUsers_removebtn_Click);
            // 
            // addUsers_updatebtn
            // 
            this.addUsers_updatebtn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.addUsers_updatebtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DeepSkyBlue;
            this.addUsers_updatebtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DeepSkyBlue;
            this.addUsers_updatebtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_updatebtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_updatebtn.Location = new System.Drawing.Point(161, 338);
            this.addUsers_updatebtn.Margin = new System.Windows.Forms.Padding(4);
            this.addUsers_updatebtn.Name = "addUsers_updatebtn";
            this.addUsers_updatebtn.Size = new System.Drawing.Size(135, 62);
            this.addUsers_updatebtn.TabIndex = 9;
            this.addUsers_updatebtn.Text = "Update";
            this.addUsers_updatebtn.UseVisualStyleBackColor = false;
            this.addUsers_updatebtn.Click += new System.EventHandler(this.addUsers_updatebtn_Click);
            // 
            // addUsers_addbtn
            // 
            this.addUsers_addbtn.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.addUsers_addbtn.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lime;
            this.addUsers_addbtn.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lime;
            this.addUsers_addbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.addUsers_addbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_addbtn.Location = new System.Drawing.Point(4, 338);
            this.addUsers_addbtn.Margin = new System.Windows.Forms.Padding(4);
            this.addUsers_addbtn.Name = "addUsers_addbtn";
            this.addUsers_addbtn.Size = new System.Drawing.Size(135, 62);
            this.addUsers_addbtn.TabIndex = 8;
            this.addUsers_addbtn.Text = "Add";
            this.addUsers_addbtn.UseVisualStyleBackColor = false;
            this.addUsers_addbtn.Click += new System.EventHandler(this.addUsers_addbtn_Click);
            // 
            // addUsers_password
            // 
            this.addUsers_password.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_password.Location = new System.Drawing.Point(27, 192);
            this.addUsers_password.Margin = new System.Windows.Forms.Padding(4);
            this.addUsers_password.Name = "addUsers_password";
            this.addUsers_password.Size = new System.Drawing.Size(280, 34);
            this.addUsers_password.TabIndex = 3;
            this.addUsers_password.TextChanged += new System.EventHandler(this.addUsers_password_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(28, 159);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 29);
            this.label2.TabIndex = 2;
            this.label2.Text = "Password";
            // 
            // addUsers_Username
            // 
            this.addUsers_Username.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addUsers_Username.Location = new System.Drawing.Point(27, 95);
            this.addUsers_Username.Margin = new System.Windows.Forms.Padding(4);
            this.addUsers_Username.Name = "addUsers_Username";
            this.addUsers_Username.Size = new System.Drawing.Size(280, 34);
            this.addUsers_Username.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(28, 62);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Username";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Location = new System.Drawing.Point(369, 15);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(417, 682);
            this.panel2.TabIndex = 5;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.DarkGreen;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(25, 62);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(373, 597);
            this.dataGridView1.TabIndex = 13;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(20, 21);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(183, 29);
            this.label5.TabIndex = 12;
            this.label5.Text = "All User\'s Data";
            // 
            // Backbuttton
            // 
            this.Backbuttton.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.Backbuttton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Backbuttton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Backbuttton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Backbuttton.Location = new System.Drawing.Point(4, 593);
            this.Backbuttton.Margin = new System.Windows.Forms.Padding(4);
            this.Backbuttton.Name = "Backbuttton";
            this.Backbuttton.Size = new System.Drawing.Size(139, 53);
            this.Backbuttton.TabIndex = 13;
            this.Backbuttton.Text = "BACK";
            this.Backbuttton.UseVisualStyleBackColor = false;
            this.Backbuttton.Click += new System.EventHandler(this.Backbuttton_Click);
            // 
            // AdminAddUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(782, 674);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "AdminAddUser";
            this.Load += new System.EventHandler(this.AdminAddUser_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button addUsers_clearbtn;
        private System.Windows.Forms.Button addUsers_removebtn;
        private System.Windows.Forms.Button addUsers_updatebtn;
        private System.Windows.Forms.Button addUsers_addbtn;
        private System.Windows.Forms.TextBox addUsers_password;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox addUsers_Username;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Backbuttton;
    }
}
