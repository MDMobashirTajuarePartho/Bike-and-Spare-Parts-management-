﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BikeParts
{
    public partial class RegisterForm : Form
    {
        public RegisterForm()
        {
            InitializeComponent();
        }

        private void Homebtn_Click(object sender, EventArgs e)
        {
            Form1 homeForm = new Form1(); 
            homeForm.Show();              
            this.Close();
        }

        private void Nametxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void UserNametxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Passwordtxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Addresstxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void DOBtxt_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void Gendercombox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void register_btn_Click(object sender, EventArgs e)
        {
            string name = Nametxt.Text.Trim();
            string username = UserNametxt.Text.Trim();
            string password = Passwordtxt.Text.Trim();
            string address = Addresstxt.Text.Trim();
            string dobInput = DOBtxt.Text.Trim();
            DateTime dob;
            string gender = Gendercombox.SelectedItem?.ToString();

            // Validate inputs
            if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password) ||
                string.IsNullOrEmpty(address) || string.IsNullOrEmpty(gender) ||
                string.IsNullOrEmpty(dobInput) || !DateTime.TryParse(dobInput, out dob))
            {
                MessageBox.Show("Please fill all the fields correctly.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            using (SqlConnection con = DbConnection.GetConnection())
            {
                try
                {
                    con.Open();
                    string checkQuery = "SELECT COUNT(1) FROM Users WHERE Username = @username";
                    using (SqlCommand checkCmd = new SqlCommand(checkQuery, con))
                    {
                        checkCmd.Parameters.AddWithValue("@username", username);
                        int userExists = Convert.ToInt32(checkCmd.ExecuteScalar());

                        if (userExists > 0)
                        {
                            MessageBox.Show("Username already exists. Please choose a different username.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }

                    // Insert new user
                    string query = "INSERT INTO Users (Name, Username, Password, Address, DateOfBirth, Gender) VALUES (@name, @username, @password, @address, @dob, @gender)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@name", name);
                        cmd.Parameters.AddWithValue("@username", username);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.Parameters.AddWithValue("@address", address);
                        cmd.Parameters.AddWithValue("@dob", dob); 
                        cmd.Parameters.AddWithValue("@gender", gender);

                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Registration Successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        login loginForm = new login();
                        loginForm.Show();
                        this.Hide();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }



        private void login_label_Click(object sender, EventArgs e)
        {

        }

        private void RegisterForm_Load(object sender, EventArgs e)
        {

        }
    }
}
