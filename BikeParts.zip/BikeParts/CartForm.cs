﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BikeParts
{
    public partial class CartForm : Form
    {
        

        public CartForm()
        {
            InitializeComponent();
            
        }
        public string Username { get; set; }

        private void Bkash_Click(object sender, EventArgs e)
        {
            Payment payment = new Payment();
            string bikePrice = textBox1.Text; 
            string partName = textBox2.Text;  
            payment.SetPaymentData(bikePrice); 
            payment.PartName = partName; 
            payment.Username = Username;
            payment.Show();
            this.Hide();
        }

        private void Back_Click(object sender, EventArgs e)
        {
            Purchasecs purchasecs = new Purchasecs();
            purchasecs.Show();
            this.Hide();
        }
        public void SetCartData(string bikeName, string bikePrice)
        {
            textBox2.Text = bikeName;
            textBox1.Text = bikePrice;
        }
        public void SetCartData1(string partName, string Price)
        {
            textBox2.Text = partName;
            textBox1.Text = Price;

        }
        private void Rocket_Click(object sender, EventArgs e)
        {
            Payment payment = new Payment();
            string bikePrice = textBox1.Text; 
            string partName = textBox2.Text;
            payment.SetPaymentData(bikePrice); 
            payment.PartName = partName; 
            payment.Username = Username;
            payment.Show();
            this.Hide();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
