﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace BikeParts
{
    public partial class Payment : Form
    {
        

        public Payment()
        {
            InitializeComponent();
        }
         public string Username { get; set; }
        public string BikeName { get; set; }
        public string PartName { get; set; }
        public string TotalPrice { get; set; }

        private void Payment_Load(object sender, EventArgs e)
        {
        }

        public void SetPaymentData(string bikePrice)
        {
            Totalamounttxt.Text = bikePrice;
        }

        public void SetPaymentData1(string price)
        {
            Totalamounttxt.Text = price;
        }
        

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
        }

        private void Cardtxt_TextChanged(object sender, EventArgs e)
        {
        }

        private void Pincodetxt_TextChanged(object sender, EventArgs e)
        {
        }

        private void Totalamounttxt_TextChanged(object sender, EventArgs e)
        {
        }

        public void SetPartName(string partName)
        {
            PartName = partName;
        }

        private void Conformbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(Username))
            {
                MessageBox.Show("Username is missing. Please log in again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string bkashNumber = Bkashtxt.Text.Trim();
            string rocketNumber = Cardtxt.Text.Trim();
            string cvv = Pincodetxt.Text.Trim();
            string totalPrice = Totalamounttxt.Text.Trim();

            if ((!string.IsNullOrEmpty(bkashNumber) || !string.IsNullOrEmpty(rocketNumber))
                && !string.IsNullOrEmpty(cvv) && !string.IsNullOrEmpty(totalPrice))
            {
                try
                {
                    string bikeName = string.IsNullOrEmpty(BikeName) ? "N/A" : BikeName;
                    string partName = string.IsNullOrEmpty(PartName) ? "N/A" : PartName;
                    string bkashNo = string.IsNullOrEmpty(bkashNumber) ? "N/A" : bkashNumber;
                    string rocketNo = string.IsNullOrEmpty(rocketNumber) ? "N/A" : rocketNumber;

                    using (SqlConnection con = DbConnection.GetConnection())
                    {
                        con.Open();
                        string query = "INSERT INTO BuyingCustomer (Username, BkashNo, RocketNo, BikeName, PartName, TotalPrice) " +
                                       "VALUES (@Username, @BkashNo, @RocketNo, @BikeName, @PartName, @TotalPrice)";

                        using (SqlCommand cmd = new SqlCommand(query, con))
                        {
                            cmd.Parameters.AddWithValue("@Username", Username);
                            cmd.Parameters.AddWithValue("@BkashNo", bkashNo); // Use default value for BkashNo
                            cmd.Parameters.AddWithValue("@RocketNo", rocketNo); // Use default value for RocketNo
                            cmd.Parameters.AddWithValue("@BikeName", bikeName); // Use default value for BikeName
                            cmd.Parameters.AddWithValue("@PartName", partName); // Use default value for PartName

                            if (decimal.TryParse(totalPrice, out decimal parsedTotalPrice))
                            {
                                cmd.Parameters.AddWithValue("@TotalPrice", parsedTotalPrice);
                            }
                            else
                            {
                                throw new Exception("Invalid total price format.");
                            }

                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Payment Successful! Details saved to the BuyingCustomer table.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error saving payment details: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Please fill in the credentials correctly, including the total price.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void Back_Click(object sender, EventArgs e)
        {
            // Navigate back to the CartForm
            CartForm frm = new CartForm();
            frm.ShowDialog();
            this.Hide();
        }

        

       
    }
}