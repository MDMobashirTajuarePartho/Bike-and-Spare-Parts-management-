﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace BikeParts
{
    public partial class AdminAddBikes : Form
    {
        public AdminAddBikes()
        {
            InitializeComponent();
        }

        private void addUsers_addbtn_Click(object sender, EventArgs e)
        {
            string bikeName = Addpartstxt.Text.Trim();
            string bikePrice = Price.Text.Trim();

            if (string.IsNullOrEmpty(bikeName))
            {
                MessageBox.Show("Please enter a bike name.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(bikePrice) || !decimal.TryParse(bikePrice, out _))
            {
                MessageBox.Show("Please enter a valid price.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            AddBike(bikeName, bikePrice);
            Addpartstxt.Clear();
            Price.Clear();
        }

        private void AddBike(string bikeName, string bikePrice)
        {
            string query = "INSERT INTO AdminData (BikeName, BikePrice) VALUES (@bikeName, @bikePrice)";

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@bikeName", bikeName);
                        cmd.Parameters.AddWithValue("@bikePrice", bikePrice);
                        cmd.ExecuteNonQuery();
                    }
                }
                MessageBox.Show("Bike added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                
                LoadBikesToGrid();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding bike: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LoadBikesToGrid()
        {
            using (SqlConnection con = DbConnection.GetConnection())
            {
                try
                {
                    con.Open();
                    string query = "SELECT BikeName, BikePrice FROM AdminData"; // Fetch BikeName and BikePrice
                    using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dataGridView1.DataSource = dt; // Replace with your DataGridView's name
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database Error: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Ensure it's not the header row
            {
                string bikeName = dataGridView1.Rows[e.RowIndex].Cells["BikeName"].Value.ToString();
                string bikePrice = dataGridView1.Rows[e.RowIndex].Cells["BikePrice"].Value.ToString();
                MessageBox.Show($"You clicked on bike: {bikeName}, Price: {bikePrice}", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void addUsers_removebtn_Click(object sender, EventArgs e)
        {
            string bikeName = Addpartstxt.Text.Trim();

            if (string.IsNullOrEmpty(bikeName))
            {
                MessageBox.Show("Please enter a bike name to delete.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool bikeExists = false;
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (row.Cells[0].Value.ToString().Equals(bikeName, StringComparison.OrdinalIgnoreCase))
                {
                    bikeExists = true;
                    break;
                }
            }

            if (!bikeExists)
            {
                MessageBox.Show("Bike not found in the list.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            DeleteBikeFromDatabase(bikeName);
        }

        private void DeleteBikeFromDatabase(string bikeName)
        {
            string query = "DELETE FROM AdminData WHERE BikeName = @bikeName";

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@bikeName", bikeName);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Bike deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadBikesToGrid();
                        }
                        else
                        {
                            MessageBox.Show("Error deleting bike: Bike not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting bike: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void addUsers_clearbtn_Click(object sender, EventArgs e)
        {
            Addpartstxt.Text = string.Empty;
            Price.Text = string.Empty;
        }

        private void addUsers_updatebtn_Click(object sender, EventArgs e)
        {
            string bikeName = Addpartstxt.Text.Trim();
            string bikePrice = Price.Text.Trim();

            if (string.IsNullOrEmpty(bikeName))
            {
                MessageBox.Show("Please enter a bike name to update.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (string.IsNullOrEmpty(bikePrice) || !decimal.TryParse(bikePrice, out _))
            {
                MessageBox.Show("Please enter a valid price.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Check if the bike exists in the database
            bool bikeExists = false;
            using (SqlConnection connection = DbConnection.GetConnection())
            {
                connection.Open();
                string checkQuery = "SELECT COUNT(*) FROM AdminData WHERE BikeName = @bikeName";
                using (SqlCommand cmd = new SqlCommand(checkQuery, connection))
                {
                    cmd.Parameters.AddWithValue("@bikeName", bikeName);
                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        bikeExists = true;
                    }
                }
            }

            if (bikeExists)
            {
                // Update the bike details
                UpdateBikeInDatabase(bikeName, bikePrice);
            }
            else
            {
                MessageBox.Show("Bike not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void UpdateBikeInDatabase(string bikeName, string bikePrice)
        {
            string query = "UPDATE AdminData SET BikePrice = @bikePrice WHERE BikeName = @bikeName";

            try
            {
                using (SqlConnection connection = DbConnection.GetConnection())
                {
                    connection.Open();
                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@bikeName", bikeName);
                        cmd.Parameters.AddWithValue("@bikePrice", bikePrice);
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Bike updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadBikesToGrid(); // Refresh the grid
                        }
                        else
                        {
                            MessageBox.Show("Error updating bike.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating bike: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Addpartstxt_TextChanged(object sender, EventArgs e)
        {
        }

        private void label5_Click(object sender, EventArgs e)
        {
        }

        private void AdminAddBikes_Load(object sender, EventArgs e)
        {
            LoadBikesToGrid();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            // Optional: Customize the panel's appearance
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            // Optional: Customize the panel's appearance
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Admin form = new Admin();
            form.Show();
            this.Hide();
        }

        private void Price_TextChanged(object sender, EventArgs e)
        {
        }
    }
}
